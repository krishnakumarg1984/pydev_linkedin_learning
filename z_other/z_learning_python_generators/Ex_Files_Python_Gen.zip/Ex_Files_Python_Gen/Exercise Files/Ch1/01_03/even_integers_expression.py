
even_integers = (n for n in range(10) if n%2==0)

