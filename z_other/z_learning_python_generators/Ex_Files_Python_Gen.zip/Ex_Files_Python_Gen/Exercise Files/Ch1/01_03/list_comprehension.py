# list comprehension
newlist = [item.upper() for item in collection]

# generator expression
(item.upper() for item in collection)
