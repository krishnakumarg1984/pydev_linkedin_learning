names_list = ['Adam','Anne','Barry','Brianne','Charlie','Cassandra','David','Dana']

#Converts names to uppercase
uppercase_names = (name.upper() for name in names_list)
