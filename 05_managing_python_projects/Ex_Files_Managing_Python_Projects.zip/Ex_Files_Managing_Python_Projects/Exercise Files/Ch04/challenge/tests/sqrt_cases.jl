{ "value": 1, "out": 1, "error": false}
{ "value": 2, "out": 1.4142, "error": false}
{ "value": 4, "out": 2, "error": false}
{ "value": -2, "out": 0, "error": true}
