def add(x, y):
    return x + y


def sub(x, y):
    return x - y
