"""Some (slow) math functions

>>> add(1, 7)
8
>>> sub(1, 7)
-6
"""

__version__ = '0.1.0'


def add(x, y):
    return x + y


def sub(x, y):
    return x - y
