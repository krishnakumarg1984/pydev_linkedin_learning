# slowmath - Some (slow) math functions


## Example

```python

>>> import slowmath
>>> slowmath.add(1, 7)
8
>>> slowmath.sub(1, 7)
-6
```

## Hacking

Run `make test`


## License

[MIT](LICENSE.txt)
